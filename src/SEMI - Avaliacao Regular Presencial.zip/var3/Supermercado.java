package var3;

public class Supermercado extends Nota {
    public Supermercado(String data, String descricao, String categoria) {
        super(data, descricao, categoria);
    }
}
