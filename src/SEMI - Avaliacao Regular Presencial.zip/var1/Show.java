package var1;
public class Show extends ItemAgrupado {

    public Show(String titulo, String genero, String diretor) {
        super(titulo, genero, diretor);
    }

}
