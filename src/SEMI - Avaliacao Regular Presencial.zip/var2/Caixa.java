package var2;

public class Caixa extends Container {
    public Caixa(String nome, String tipo, String fabricante) {
        super(nome, tipo, fabricante);
    }
    
}
